A Pen created at CodePen.io. You can find this one at http://codepen.io/matheusxaviersi/pen/yJKDh.

 [optimized version of Danic Filip original idea.](http://codepen.io/FilipDanic/details/oGbce/)
re-made the effects and adjusted timing.